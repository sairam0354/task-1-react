const Main3=()=>{
  let img="https://technext.github.io/LaslesVPN/v1.0.0/assets/img/gallery/user-1.png";

  return(
    <div>
       <div class="sixth-box">
            <div class="box1">
              <h1><br/><br/>Trusted by Thousands of<br/> Happy Customer </h1><br/>
              <p> These are the stories of our customers who have joined us <br/>with great pleasure when using this crazy feature. </p>
            </div><br/><br/><br/>
            <div class="box2">
              <div class="box-a">
                <div class="a1">
                   <img src={img}/>
                   Sairam
                   <h3>4.5 *</h3>
                     </div>
                 <p>Wow...I am very happy to use this VPN, it turned out to be more than my expectations and so far there have been no problems. LaslesVPN always the best</p>
              </div>
              <div class="box-b"> <div class="a1">
                   <img src={img}/>
                   Sairam
                   <h3>4.5 *</h3>
                     </div>
                 <p>Wow...I am very happy to use this VPN, it turned out to be more than my expectations and so far there have been no problems. LaslesVPN always the best</p>
              </div>
              <div class="box-c"> <div class="a1">
                   <img src={img}/>
                   Sairam
                   <h3>4.5 *</h3>
                     </div>
                 <p>Wow...I am very happy to use this VPN, it turned out to be more than my expectations and so far there have been no problems. LaslesVPN always the best</p>
              </div>
              <div class="box-d"> <div class="a1">
                   <img src={img}/>
                   Sairam
                   <h3>4.5 *</h3>
                     </div>
                 <p>Wow...I am very happy to use this VPN, it turned out to be more than my expectations and so far there have been no problems. LaslesVPN always the best</p>
              </div>
              <div class="box-e"> <div class="a1">
                   <img src={img}/>
                   Sairam
                   <h3>4.5 *</h3>
                     </div>
                 <p>Wow...I am very happy to use this VPN, it turned out to be more than my expectations and so far there have been no problems. LaslesVPN always the best</p>
              </div>

            </div>
      </div><br/><br/><br/><br/><br/><br/><br/>

      <div class="seventh-box">
        <div class="one">
          <h1>Subscribe Now for
            Get Special Features!
            </h1><br/>
            <p> Let's subscribe with us and find the fun.    </p>
        </div><br/>
        <button>Subscribe Now</button>
      </div><br/><br/><br/><br/><br/><br/>
    </div>
  )
}
export default Main3;